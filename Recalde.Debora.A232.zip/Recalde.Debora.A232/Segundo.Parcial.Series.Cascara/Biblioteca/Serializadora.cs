﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Biblioteca
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        public void Guardar(List<Serie> item, string ruta)
        {
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(ruta))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(Serie));
                    xmlSerializer.Serialize(streamWriter, item);
                }

            }
            catch (Exception ex)
            {
                throw new BackLogException("Se produjo un error: " + ex.Message);
            }
        }
        void IGuardar<List<Serie>>.Guardar(List<Serie> item, string ruta)
        {
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(ruta))
                {
                    string jsonString = JsonSerializer.Serialize(item);
                    streamWriter.Write(jsonString);
                }

            }
            catch (Exception ex)
            {
                throw new BackLogException("Se produjo un error: " + ex.Message);
            }
        }
    }
}
