﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class BackLogException : Exception
    {
        public BackLogException(string message):base(message)
        {
            
        }

        public BackLogException(string message, Exception inner) : base(message,inner)
        {

        }
    }
}
