﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public static class AccesoDatos
    {
        private static string cadenaConexion;
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static AccesoDatos()
        {
            cadenaConexion = @"Data Source=.;Initial Catalog=20240701-SP;Integrated Security=True";
            comando = new SqlCommand();
            conexion = new SqlConnection(cadenaConexion);
            comando.Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
        }

        public static void ActualizarSerie(Serie serie)
        {
            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText = "UPDATE series SET alumno = @alumno WHERE nombre = @nombre";
                comando.Parameters.AddWithValue("@alumno", "Debora Recalde");
                comando.Parameters.AddWithValue("@alumno", serie.Nombre);
                comando.ExecuteNonQuery();

            }
            finally
            {
                conexion.Close();
            }
        }

        public static List<Serie> ObtenerBacklog()
        {
            List<Serie> lista = new List<Serie>();
            try
            {
                conexion.Open();
                comando.CommandText = "SELECT nombre, genero, alumno FROM dbo.series";

                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        lista.Add(new Serie(dataReader["GENERO"].ToString(), dataReader["NOMBRE"].ToString()));
                    }
                    return lista;
                }
            }
            finally
            {
                conexion.Close();
            }
        }
    }
}
