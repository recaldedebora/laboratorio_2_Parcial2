﻿using System.Text;

namespace Biblioteca
{
    public class Serie
    {
        private string genero;
        private string nombre;

        public Serie()
        {
            
        }

        public Serie(string genero, string nombre)
        {
            this.genero = genero;
            this.nombre = nombre;
        }

        public string Genero { get => genero; set => genero = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(nombre);
            sb.Append(genero);
            return sb.ToString();
        }
    }
}