﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    
    public delegate void DelegadoBacklog(Serie serie);
    public class ManejadorBackLog
    {

        public event DelegadoBacklog NuevaserieParaVer;
        public void IniciarManejador(List<Serie> series)
        {
            Task.Run(() => MoverSeries(series));
        }
        private void MoverSeries(List<Serie> series)
        {
            while (series.Count > 0)
            {
                int indiceAleatorio = series.GenerarRandom();
                Serie serie = series[indiceAleatorio];
                AccesoDatos.ActualizarSerie(serie);
                Thread.Sleep(1500);
                NuevaserieParaVer.Invoke(serie);
                series.RemoveAt(indiceAleatorio);
            }
        }
    }
}
