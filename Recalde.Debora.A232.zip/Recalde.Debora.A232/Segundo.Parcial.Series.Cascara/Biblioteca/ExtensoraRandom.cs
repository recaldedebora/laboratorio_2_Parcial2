﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public static class ExtensoraRandom
    {
        //public static int GenerarRandom(this ManejadorBackLog manejador, int maximo)
        //{
        //    Random random = new Random();
        //    return random.Next(0, maximo);
        //}

        public static int GenerarRandom(this List<Serie> lista)
        {
            Random random = new Random();
            return random.Next(0, lista.Count);
        }
    }
}
