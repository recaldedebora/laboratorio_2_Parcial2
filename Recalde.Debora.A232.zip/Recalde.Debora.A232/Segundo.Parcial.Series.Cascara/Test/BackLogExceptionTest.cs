﻿using Biblioteca;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    [TestClass]
    public class BackLogExceptionTest
    {
        [TestMethod]
        public void BackLogException_DeberiaLanzarException()
        {
            //Arrange
            Serializadora serializadora = new Serializadora();
            List<Serie> series = null;
            string rutaXml = Path.Combine(Path.GetTempPath(), "SeriesBacklog.xml");
            //Act
            //Assert
            try
            {
                serializadora.Guardar(series, rutaXml);
                Assert.Fail("Se esperaba que se lanzara una BackLogException.");
            }
            catch (BackLogException ex)
            {
                StringAssert.Contains("Se produjo un error", ex.Message);
            }
        }

    }
    
}
