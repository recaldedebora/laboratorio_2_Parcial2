using Biblioteca;

namespace Test
{
    [TestClass]
    public class SerializadoraTests
    {
        [TestMethod]
        public void GuardarXml_SerializesListToXml()
        {
            // Arrange
            Serializadora serializadora = new Serializadora();
            List<Serie> series = new List<Serie>();
            series.Add(new Serie("TestGenero", "TestNombre"));
            string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaXml = Path.Combine(rutaEscritorio, "Backlog.xml");


            // Act
            serializadora.Guardar(series, rutaXml);

            // Assert
            Assert.IsTrue(File.Exists(rutaXml));
            string contenidoArchivo = File.ReadAllText(rutaXml);
            Assert.IsTrue(contenidoArchivo.Contains("TestNombre"));
            
        }
    }
}